<?php
$token = '7455639964:AAF_uU5vfd-4prdHpFJGkGakNNj4_Mm3ilQ';    // Ganti dengan token asli Anda
$chatid = '7649922917';     // Ganti dengan chat ID tujuan